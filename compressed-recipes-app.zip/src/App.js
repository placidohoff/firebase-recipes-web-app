import { useEffect, useState } from 'react'
import FirebaseAuthService from './FirebaseAuthService';

import './App.css';
import LoginForm from './components/LoginForm';
import AddEditRecipeForm from './components/AddEditRecipeForm';
import FirebaseFirestoreService from './FirebaseFirestoreService';

function App() {
  const [user, setUser] = useState(null)
  const [recipes, setRecipes] = useState([])

  useEffect(() => {
    fetchRecipes()
      .then((fetchedRecipes) => {
        setRecipes(fetchedRecipes);
      })
      .catch((error) => {
        console.error(error.message);
        throw error
      })
  }, [user])

  //Whenever there is a change in the user, we will call our custom handler which in this case is simply setState
  FirebaseAuthService.subscribeToAuthChanges(setUser);

  async function fetchRecipes() {
    const queries = [];

    if(!user){
      queries.push({
        field: 'isPublished',
        condition: '==',
        value: true
      })
    }

    let fetchedRecipes = [];

    try {
      const response = await FirebaseFirestoreService.readDocuments({collection:'Recipes', queries: queries});

      const newRecipes = response.docs.map((recipeDoc) => {
        const id = recipeDoc.id
        const data = recipeDoc.data();
        console.log(data)
        // data.publishDate = new Date(data.publishDate.seconds * 1000)

        return { ...data, id }
      })

      fetchedRecipes = [...newRecipes]
    } catch (error) {

      console.error(error.message)
      throw error

    }

    return fetchedRecipes
  }

  //The following function is called manually whenever a new recipe is sucessfully added. Display new results. 
  //The original fetchRecipes is called via useState() whenever a new user logs in.
  async function handleFetchRecipes() {
    try {
      const fetchedRecipes = await fetchRecipes();

      setRecipes(fetchedRecipes)

    } catch (error) {

      console.error(error.message)
      throw error;

    }
  }

  async function handleAddRecipe(newRecipe) {
    try {

      const response = await FirebaseFirestoreService.createDocument('Recipes', newRecipe);

      handleFetchRecipes();

      alert(`Sucessfully created a recipe with an ID = ${response.id}`)
    } catch (error) {

      alert(error.message);

    }
  }

  function lookupCategoryLabel(categoryKey) {
    const categories = {
      breadsSandwichesAndPizza: "Breads, Sandwiches, and Pizza",
      eggsAndBreakfast: "Eggs & Breakfast",
      dessertsAndBakedGoods: "Desserts & Baked Goods",
      fishAndSeafood: "Fish & Seafood",
      vegetables: "Vegetables"
    };

    const label = categories[categoryKey];

    return label;
  }

  function formatDate(date) {
    let dateString
    console.log(date)

    const milliseconds = date.seconds * 1000;
    let dateFix = new Date(milliseconds)
    // if (date instanceof Date) {
    //   const day = date.getUTCDate();
    //   const month = date.getUTCMonth() + 1;
    //   const year = date.getFullYear();
    //   dateString = `${month}-${day}-${year}`;
    // }

    const day = dateFix.getUTCDate();
    const month = dateFix.getUTCMonth() + 1;
    const year = dateFix.getFullYear();
    dateString = `${month}-${day}-${year}`;
    return dateString;
  }

  return (
    <div className="App">
      <div className="title-row">
        <h1 className='title'>Recipes App</h1>
        <LoginForm existingUser={user} />
      </div>
      <div className='main'>
        <div className='center'>
          <div className='recipes-list-box'>
            {
              recipes && recipes.length > 0 && (
                <div className='recipe-list'>
                  {
                    recipes.map((recipe) => {
                      return (
                        <div className='recipe-card' key={recipe.id}>
                          {
                            recipe.isPublished === false && <div className='unpublished'>UNPUBLISHED</div>
                          }
                          <div className='recipe-name'>{recipe.name}</div>
                          <div className='recipe-field'>Category: {lookupCategoryLabel(recipe.category)}</div>
                          {
                            recipe.publishDate && <div className='recipe-field'>Publish Date: {formatDate(recipe.publishDate)}</div>
                          }

                        </div>

                      )
                    })
                  }

                </div>
              )
            }

          </div>
        </div>
        {
          user && <AddEditRecipeForm handleAddRecipe={handleAddRecipe} />
        }

      </div>
    </div>
  );
}

export default App;
